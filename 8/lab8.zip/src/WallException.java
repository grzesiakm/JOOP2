public class WallException extends IndexOutOfBoundsException {
    public WallException() {
        ArrayIndexOutOfBoundsException e = new ArrayIndexOutOfBoundsException();
        throw e;
    }
}
