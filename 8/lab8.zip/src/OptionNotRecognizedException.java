import java.util.InputMismatchException;

public class OptionNotRecognizedException extends InputMismatchException {
    public OptionNotRecognizedException() {
       InputMismatchException e = new InputMismatchException();
        throw e;
    }
}
